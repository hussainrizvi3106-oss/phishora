/* Phishora detection engine + UI. Runs fully in the browser; nothing is uploaded. */
"use strict";

const BRANDS = {
  paypal: ["paypal.com"], google: ["google.com", "google.co.in", "gmail.com"], microsoft: ["microsoft.com", "live.com", "office.com", "outlook.com"],
  apple: ["apple.com", "icloud.com"], amazon: ["amazon.com", "amazon.in", "amazon.co.uk"], facebook: ["facebook.com", "fb.com"],
  instagram: ["instagram.com"], netflix: ["netflix.com"], whatsapp: ["whatsapp.com"], github: ["github.com"], linkedin: ["linkedin.com"],
  paytm: ["paytm.com"], phonepe: ["phonepe.com"], flipkart: ["flipkart.com"], hdfcbank: ["hdfcbank.com"], icicibank: ["icicibank.com"],
  sbi: ["sbi.co.in", "onlinesbi.sbi", "sbi.bank.in"], irctc: ["irctc.co.in"], dhl: ["dhl.com"], fedex: ["fedex.com"]
};
const TRUSTED = ["wikipedia.org", "python.org", "mozilla.org", "stackoverflow.com", "bbc.com", "bbc.co.uk", "openai.com", "anthropic.com",
  "claude.ai", "youtube.com", "x.com", "twitter.com", "reddit.com", "incometax.gov.in", "india.gov.in", "manavrachna.edu.in"]
  .concat(...Object.values(BRANDS));
const SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "ow.ly", "tiny.cc", "rebrand.ly"];
const RISKY_TLDS = ["tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "zip", "work", "support", "buzz", "country", "icu", "rest", "monster"];
const URL_WORDS = ["login", "signin", "verify", "secure", "account", "update", "confirm", "alert", "claim", "prize", "suspend", "unlock", "password", "wallet", "kyc", "bonus", "refund"];

const SMS_RULES = [
  { re: /\b(urgent|immediately|right away|within \d+ ?(hours?|hrs?|mins?|minutes?)|last warning|final notice|today only|act now|expires? (today|soon))\b/i, pts: 15, why: "Creates urgency to rush you" },
  { re: /\b(otp|one[- ]time password|cvv|pin|password|card number|net ?banking|upi pin)\b/i, pts: 25, why: "Asks for or mentions secret codes or passwords" },
  { re: /\b(kyc|pan card|aadhaar|aadhar)\b.*\b(update|expire|block|suspend|verify|pending)\b|\b(update|verify|complete)\b.*\b(kyc|pan|aadhaar|aadhar)\b/i, pts: 25, why: "KYC / ID update scam pattern" },
  { re: /\b(account|card|sim|wallet|upi|number|service)\b.{0,30}\b(blocked|suspended|deactivated|frozen|disconnected|expired|closed)\b/i, pts: 20, why: "Threatens to block or suspend something" },
  { re: /\b(you (have )?won|winner|lottery|lucky draw|prize|reward points?|cashback|free gift|congratulations|claim your)\b/i, pts: 22, why: "Offers a prize or reward you did not ask for" },
  { re: /\b(electricity|power|gas|water) (bill|supply|connection)\b.*\b(disconnect|cut|tonight|pending)\b/i, pts: 22, why: "Fake utility-bill disconnection pattern" },
  { re: /\b(customs|parcel|package|courier|delivery)\b.*\b(held|pending|failed|fee|charges?|reschedule|address)\b/i, pts: 18, why: "Fake parcel / delivery fee pattern" },
  { re: /\b(income tax|it refund|tax refund|refund of)\b/i, pts: 15, why: "Refund bait" },
  { re: /\b(work from home|part[- ]time job|earn (rs\.?|inr|₹|\$)? ?\d+|per day|daily income|investment|double your)\b/i, pts: 18, why: "Job / easy-money / investment bait" },
  { re: /\b(dear (customer|user|account holder|sir|madam)|valued customer)\b/i, pts: 8, why: "Generic greeting instead of your name" },
  { re: /\b(call|whatsapp|contact)\b.{0,25}(\+?\d[\d -]{8,})/i, pts: 12, why: "Pushes you to call or message an unknown number" },
  { re: /\b(click|tap|open|visit)\b.{0,20}\b(link|here|below)\b/i, pts: 8, why: "Tells you to click a link" }
];

function registrable(host) {
  const p = host.split(".");
  if (p.length <= 2) return host;
  if (/^(co|com|org|net|ac|gov|edu|nic)$/.test(p[p.length - 2]) && p[p.length - 1].length === 2) return p.slice(-3).join(".");
  return p.slice(-2).join(".");
}
function deLeet(s) {
  return s.replace(/rn/g, "m").replace(/vv/g, "w").replace(/0/g, "o").replace(/[1|]/g, "l").replace(/5/g, "s").replace(/3/g, "e").replace(/4/g, "a");
}

/* ---- URL analysis ---- */
function analyzeURL(input) {
  const raw = String(input || "").trim();
  const out = { input: raw, score: 0, reasons: [], features: {}, valid: true, trusted: false };
  if (!raw) { out.valid = false; return out; }
  if (/^(javascript|data|vbscript):/i.test(raw)) {
    out.score = 100; out.reasons.push({ pts: 100, text: "Not a web address: this kind of link runs code in your browser" });
    return finish(out);
  }
  let u;
  try { u = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : "https://" + raw); } catch (e) { out.valid = false; return out; }
  if (!/^https?:$/.test(u.protocol) || !u.hostname.includes(".") && !/^\[/.test(u.hostname)) { out.valid = false; return out; }

  const host = u.hostname.toLowerCase().replace(/\.$/, "");
  const reg = registrable(host);
  const tld = host.split(".").pop();
  const rest = (u.pathname + u.search).toLowerCase();
  const labels = host.split(".");
  const add = (pts, text) => { out.score += pts; out.reasons.push({ pts, text }); };
  const hasAt = /@/.test(raw.replace(/^[a-z]+:\/\//i, "").split(/[/?#]/)[0]);
  const isIP = /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || /^\[/.test(host);

  out.features = {
    host, domain: reg, length: raw.length, dots: (host.match(/\./g) || []).length, hyphens: (host.match(/-/g) || []).length,
    digits: (host.match(/\d/g) || []).length, https: u.protocol === "https:", subdomains: Math.max(0, labels.length - reg.split(".").length)
  };

  out.trusted = !hasAt && !isIP && TRUSTED.includes(reg);
  if (isIP) add(35, "Uses a raw IP address instead of a website name");
  if (hasAt) add(30, "Contains an @ sign that hides the real destination");
  if (host.includes("xn--")) add(28, "Uses look-alike (punycode) characters in the domain");
  if (SHORTENERS.includes(reg)) add(22, "Link shortener hides the real destination");
  if (RISKY_TLDS.includes(tld) && !isIP) add(14, "Uses ." + tld + ", a cheap extension common in scams");
  if (out.features.subdomains >= 3) add(12, "Has many sub-domains (" + out.features.subdomains + ") stacked in front of the domain");
  if (out.features.hyphens >= 2 && !out.trusted) add(10, "Domain contains several hyphens");
  if (out.features.digits >= 3 && !isIP && !out.trusted) add(8, "Domain contains many digits");
  if (u.port && !["80", "443"].includes(u.port)) add(10, "Uses an unusual port (" + u.port + ")");
  if (!out.features.https) add(10, "Connection is not encrypted (no HTTPS)");
  if (/%[0-9a-f]{2}/i.test(rest) && (rest.match(/%[0-9a-f]{2}/gi) || []).length > 4) add(8, "Heavily encoded characters in the path");
  if (raw.length > 90) add(6, "Very long address");
  if (/\/\/.*https?:\/\//i.test(rest) || /[?&](url|redirect|next|goto|return)=https?/i.test(rest)) add(15, "Redirects to another website");

  if (!out.trusted) {
    const tokens = host.split(/[.\-]/);
    let hit = null;
    for (const [brand, official] of Object.entries(BRANDS)) {
      if (official.includes(reg)) continue;
      for (const t of tokens) {
        const n = deLeet(t);
        if (n === brand || (brand.length >= 5 && n.includes(brand))) { hit = { brand, spoof: n !== t && !t.includes(brand) }; break; }
      }
      if (hit) break;
    }
    if (hit) add(hit.spoof ? 42 : 38, hit.spoof ? "Domain imitates " + hit.brand + " using look-alike characters" : "Uses the name “" + hit.brand + "” but is not the official " + hit.brand + " website");
    const words = URL_WORDS.filter(w => host.includes(w) || rest.includes(w));
    if (words.length) add(Math.min(24, words.length * 8), "Contains pressure words: " + words.slice(0, 5).join(", "));
  }
  if (out.trusted) { out.score = Math.min(out.score, 8); out.reasons.push({ pts: 0, text: "Domain " + reg + " is on the known-safe list" }); }
  return finish(out);
}

function finish(o) {
  o.score = Math.max(0, Math.min(100, Math.round(o.score)));
  o.level = o.score >= 55 ? "danger" : o.score >= 25 ? "warn" : "safe";
  o.reasons.sort((a, b) => b.pts - a.pts);
  return o;
}

/* ---- SMS / message analysis ---- */
function extractLinks(text) {
  const m = text.match(/(?:https?:\/\/|www\.)[^\s<>"']+|\b(?:[a-z0-9-]+\.)+[a-z]{2,24}(?:\/[^\s<>"']*)?/gi) || [];
  return [...new Set(m.map(s => s.replace(/[).,;!?]+$/, "")).filter(s => !/^\d+(\.\d+)*$/.test(s)))];
}
function analyzeSMS(text) {
  const t = String(text || "").trim();
  const out = { input: t, score: 0, reasons: [], links: [], valid: !!t };
  if (!t) return out;
  SMS_RULES.forEach(r => { if (r.re.test(t)) { out.score += r.pts; out.reasons.push({ pts: r.pts, text: r.why }); } });
  const letters = t.replace(/[^a-z]/gi, "");
  if (letters.length > 20 && (t.replace(/[^A-Z]/g, "").length / letters.length) > 0.6) { out.score += 8; out.reasons.push({ pts: 8, text: "Mostly CAPITAL letters" }); }
  extractLinks(t).forEach(l => {
    const a = analyzeURL(l);
    if (!a.valid) return;
    out.links.push(a);
    if (a.level !== "safe") { const p = Math.round(a.score * 0.7); out.score += p; out.reasons.push({ pts: p, text: "Link " + a.features.host + " looks " + (a.level === "danger" ? "dangerous" : "suspicious") }); }
  });
  if (out.links.length && out.reasons.length >= 2 && !out.links.some(l => l.level !== "safe")) { out.score += 6; out.reasons.push({ pts: 6, text: "Contains a link alongside pressure tactics" }); }
  return finish(out);
}

if (typeof module !== "undefined") module.exports = { analyzeURL, analyzeSMS, registrable };

/* ---- UI ---- */
if (typeof document !== "undefined") (function () {
  const $ = id => document.getElementById(id);
  const LABEL = { safe: "Looks safe", warn: "Suspicious", danger: "Likely scam" };
  const ADVICE = {
    safe: "No scam signs found. Still, never enter passwords on a page you reached from a message.",
    warn: "Some warning signs. Do not click or reply. Open the official app or type the website yourself.",
    danger: "Do not open this or reply. Never share OTP, PIN or passwords. Report it at cybercrime.gov.in or call 1930."
  };
  let mode = "url", history = [];
  try { history = JSON.parse(localStorage.getItem("phishora_history") || "[]"); } catch (e) { history = []; }

  function setMode(m) {
    mode = m;
    $("tab-url").setAttribute("aria-selected", m === "url");
    $("tab-sms").setAttribute("aria-selected", m === "sms");
    $("input").placeholder = m === "url" ? "Paste a website link, e.g. paypa1-login.com/verify" : "Paste the full SMS or message text here";
    $("input").rows = m === "url" ? 2 : 6;
    $("input").value = ""; $("result").hidden = true; $("input").focus();
  }
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  function scan() {
    const v = $("input").value.trim();
    if (!v) { $("hint").textContent = "Paste something to scan first."; return; }
    const r = mode === "url" ? analyzeURL(v) : analyzeSMS(v);
    if (!r.valid) { $("hint").textContent = "That does not look like a web address. Check it and try again."; $("result").hidden = true; return; }
    $("hint").textContent = "";
    show(r); save(r);
  }
  function show(r) {
    const box = $("result"); box.hidden = false; box.dataset.level = r.level;
    $("verdict").textContent = LABEL[r.level];
    $("score").textContent = r.score;
    $("marker").style.left = r.score + "%";
    $("advice").textContent = ADVICE[r.level];
    const ul = $("reasons"); ul.textContent = "";
    if (!r.reasons.length) ul.appendChild(el("li", "", "No warning signs found in the " + (mode === "url" ? "address" : "message") + "."));
    r.reasons.forEach(x => ul.appendChild(el("li", "", x.text + (x.pts ? "  (+" + x.pts + ")" : ""))));
    const f = $("facts"); f.textContent = "";
    const items = r.features ? [["Domain", r.features.domain], ["HTTPS", r.features.https ? "Yes" : "No"], ["Sub-domains", r.features.subdomains], ["Hyphens", r.features.hyphens], ["Digits", r.features.digits], ["Length", r.features.length]]
      : [["Links found", r.links.length], ["Warning signs", r.reasons.length]];
    items.forEach(([k, val]) => { const d = el("div", "fact"); d.appendChild(el("span", "", k)); d.appendChild(el("b", "", String(val))); f.appendChild(d); });
    box.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "nearest" });
  }
  function save(r) {
    history.unshift({ m: mode, t: r.input.slice(0, 80), level: r.level, score: r.score });
    history = history.slice(0, 8);
    try { localStorage.setItem("phishora_history", JSON.stringify(history)); } catch (e) {}
    renderHistory();
  }
  function renderHistory() {
    const ul = $("history"); ul.textContent = "";
    $("history-wrap").hidden = !history.length;
    history.forEach(h => {
      const li = el("li"); li.dataset.level = h.level;
      li.appendChild(el("span", "pill", h.score + " " + LABEL[h.level]));
      li.appendChild(el("span", "ht", (h.m === "sms" ? "SMS: " : "") + h.t));
      ul.appendChild(li);
    });
  }
  const SAMPLES = {
    url: ["https://github.com/anthropics", "http://paypa1-login-verify.xyz/account/update", "http://192.168.4.7/secure/login", "https://secure.hdfcbank.com.kyc-update.top/login"],
    sms: ["Dear customer, your SBI account will be BLOCKED today. Update KYC immediately: http://sbi-kyc-update.top/login", "Your OTP is 482913. Do not share it with anyone. - Amazon", "Congratulations! You won Rs 25,00,000 in lucky draw. Call +91 98765 43210 to claim your prize"]
  };
  function renderSamples() {
    const w = $("samples"); w.textContent = "";
    SAMPLES[mode].forEach(s => { const b = el("button", "sample", s.length > 46 ? s.slice(0, 44) + "…" : s); b.type = "button"; b.onclick = () => { $("input").value = s; scan(); }; w.appendChild(b); });
  }
  const _setMode = setMode; setMode = function (m) { _setMode(m); renderSamples(); };

  $("tab-url").onclick = () => setMode("url");
  $("tab-sms").onclick = () => setMode("sms");
  $("scan").onclick = scan;
  $("clear").onclick = () => { $("input").value = ""; $("result").hidden = true; $("hint").textContent = ""; $("input").focus(); };
  $("wipe").onclick = () => { history = []; try { localStorage.removeItem("phishora_history"); } catch (e) {} renderHistory(); };
  $("input").addEventListener("keydown", e => { if (e.key === "Enter" && (mode === "url" || e.ctrlKey || e.metaKey)) { e.preventDefault(); scan(); } });
  renderHistory(); setMode("url");
})();
