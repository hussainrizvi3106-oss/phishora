# Phishora

Phishora checks **website links** and **SMS / messages** for phishing and scam signs. It runs entirely in the browser, so nothing you paste is uploaded anywhere.

## Run it
- Open `index.html` in any browser, or
- Publish on GitHub Pages: repo **Settings → Pages → Deploy from branch → main / (root)**. Your site will be at `https://<your-username>.github.io/<repo>/`.

## Files
| File | Purpose |
|---|---|
| `index.html` | Page layout |
| `styles.css` | Styling (light and dark mode) |
| `app.js` | Detection engine and interface |
| `test.js` | Self-test: `node test.js` |

## What it checks
**Links:** raw IP addresses, `@` tricks, look-alike letters (`paypa1`), punycode, brand names on the wrong domain (`paypal.com.evil.tk`), link shorteners, risky extensions, stacked sub-domains, missing HTTPS, redirects, pressure words.
**SMS:** urgency, OTP/PIN requests, KYC and bank-block scams, prizes and lotteries, fake delivery and electricity-bill messages, job/investment bait, plus every link inside the message.

## Fixes from the original `Phishing_URL_Detector_Ready.py`
- It was an HTML page saved with a `.py` extension, so Python could not run it. It is now a proper `index.html`.
- It had no `<html>`, `<head>` or `<body>` tags. Fixed.
- Words like "account" matched anywhere, so `https://www.amazon.in/gp/your-account` looked risky. It now knows trusted domains.
- It missed real tricks: `paypal.com.evil.tk`, `google.com@evil.xyz`, IP-address links, look-alike letters.
- It had no SMS checking. Added.
- Anything starting with `http://` was penalised equally, with no explanation. Every result now lists its reasons.

## Limits
This is a rule-based scorer, not a live blacklist. It cannot read your inbox or know about sites reported today. Extend the brand list in `app.js` (`BRANDS`) and the keyword rules (`SMS_RULES`) as you like. Report scams at cybercrime.gov.in or call 1930 (India).

Educational project by Ayush Gupta, MRIIRS.
